#! /bin/sh
dune exec bin/mutop.exe